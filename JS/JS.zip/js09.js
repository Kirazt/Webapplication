// JavaScript Document
function button()
{
	alert("Bạn đã click lên button");
}
function submit()
{
	alert("Bạn đã submit");
}
function click()
{
	alert("Bạn đang trỏ chuột");
}
function enter()
{
	alert("Bạn đã thay đổi chuổi nhập");
}
