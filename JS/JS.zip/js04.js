arr="HTML-JAVA";
function clear(){
	document.body.innerHTML="";
}
function Move(arr){
	if(arr.length>0)
		{
			arr1=arr.slice(-1) + arr.slice(0, -1);
			document.write(arr1);
			return Move(arr1);
		}
}
function loop()
{
	setInterval(Move(arr),1000);
}

